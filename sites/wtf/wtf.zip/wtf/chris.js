// JavaScript Document - stuff from chris

function runChris(){
	
}

function subFormUI(){
	$('#me-form').fadeOut();
}