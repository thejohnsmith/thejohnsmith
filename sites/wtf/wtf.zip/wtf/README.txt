Lets get hacking!


QA Live - a live and interactive question and answer service

Actions:
	Login
		Register with server
	Ask question
		posts question to server
		Refresh client view
		Server sends question to first user in queue
	Receive question
		Update question “panel”
	Answer question
		Post answer to server
		Refresh client view
	Pass on question
		Send server response “pass”
	Receive update
		Update client with number of passes
		Receive answer
	Logout
	
	
	