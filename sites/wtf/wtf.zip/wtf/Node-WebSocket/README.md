# node-websocket-server #

This is a server for the WebSocket Protocol. It currently to works
with both [draft75](http://tools.ietf.org/html/draft-hixie-thewebsocketprotocol-75) and [draft76](http://www.whatwg.org/specs/web-socket-protocol/) of the protocol specification.

See http://static.brandedcode.com/nws-docs/ for some slightly outdated
documentation.